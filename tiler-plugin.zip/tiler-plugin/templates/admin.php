<?php

// $page = get_page_by_title('Shop', OBJECT, 'page');

// echo '<pre>';

// print_r($page->ID);

// echo get_stylesheet_directory();